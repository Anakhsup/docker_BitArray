#include "../include/BigArray.h"
#include <iostream>

int main() {
	BitArray a;
	
}
