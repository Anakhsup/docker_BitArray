#include <gtest/gtest.h>
#include "../include/BigArray.h"
#include "../src/BigArray.cpp"

TEST(BitArrayTest, ConstructorDefault) {
    BitArray b;
    EXPECT_EQ(b.size(), 0);
    EXPECT_TRUE(b.empty());
}

TEST(BitArrayTest, ConstructorWithParameters) {
    BitArray b(10, true);
    EXPECT_EQ(b.size(), 10);
    EXPECT_EQ(b.count(), 10);
}

TEST(BitArrayTest, CopyConstructor) {
    BitArray b1(5, true);
    BitArray b2(b1);
    EXPECT_EQ(b2.size(), 5);
    EXPECT_EQ(b2.count(), 5);
    EXPECT_EQ(b1, b2);
}

TEST(BitArrayTest, AssignmentOperator) {
    BitArray b1(5, true);
    BitArray b2;
    b2 = b1;
    EXPECT_EQ(b2.size(), 5);
    EXPECT_EQ(b2.count(), 5);
    EXPECT_EQ(b1, b2);
}

TEST(BitArrayTest, Swap) {
    BitArray b1(5, true);
    BitArray b2(5, false);
    b1.swap(b2);
    EXPECT_EQ(b1.count(), 0);
    EXPECT_EQ(b2.count(), 5);
}

TEST(BitArrayTest, Resize) {
    BitArray b(5, true);
    b.resize(10, false);
    EXPECT_EQ(b.size(), 10);
    EXPECT_EQ(b.count(), 5);
}

TEST(BitArrayTest, Clear) {
    BitArray b(5, true);
    b.clear();
    EXPECT_EQ(b.size(), 0);
    EXPECT_TRUE(b.empty());
}

TEST(BitArrayTest, PushBack) {
    BitArray b;
    b.push_back(true);
    EXPECT_EQ(b.size(), 1);
    EXPECT_EQ(b.count(), 1);
}

TEST(BitArrayTest, AndOperator) {
    BitArray b1(5, true);
    BitArray b2(5, false);
    b1 &= b2;
    EXPECT_EQ(b1.count(), 0);
}

TEST(BitArrayTest, OrOperator) {
    BitArray b1(5, true);
    BitArray b2(5, false);
    b1 |= b2;
    EXPECT_EQ(b1.count(), 5);
}

TEST(BitArrayTest, XorOperator) {
    BitArray b1(5, true);
    BitArray b2(5, true);
    b1 ^= b2;
    EXPECT_EQ(b1.count(), 0);
}

TEST(BitArrayTest, LeftShiftOperator) {
    BitArray b(5, true);
    b <<= 2;
    EXPECT_EQ(b.count(), 3);
}

TEST(BitArrayTest, RightShiftOperator) {
    BitArray b(5, true);
    b >>= 2;
    EXPECT_EQ(b.count(), 3);
}

TEST(BitArrayTest, Set) {
    BitArray b(5, false);
    b.set(2, true);
    EXPECT_TRUE(b[2]);
    b.set();
    EXPECT_EQ(b.count(), 5);
}

TEST(BitArrayTest, Reset) {
    BitArray b(5, true);
    b.reset(2);
    EXPECT_FALSE(b[2]);
    b.reset();
    EXPECT_EQ(b.count(), 0);
}

TEST(BitArrayTest, Any) {
    BitArray b(5, false);
    EXPECT_FALSE(b.any());
    b.set(2, true);
    EXPECT_TRUE(b.any());
}

TEST(BitArrayTest, None) {
    BitArray b(5, false);
    EXPECT_TRUE(b.none());
    b.set(2, true);
    EXPECT_FALSE(b.none());
}

TEST(BitArrayTest, NotOperator) {
    BitArray b(5, true);
    BitArray b_not = ~b;
    EXPECT_EQ(b_not.count(), 0);
}

TEST(BitArrayTest, Count) {
    BitArray b(5, true);
    EXPECT_EQ(b.count(), 5);
    b.reset(2);
    EXPECT_EQ(b.count(), 4);
}

TEST(BitArrayTest, ToString) {
    BitArray b(5, true);
    EXPECT_EQ(b.to_string(), "11111");
    b.reset(2);
    EXPECT_EQ(b.to_string(), "11011");
}

TEST(BitArrayTest, EqualityOperator) {
    BitArray b1(5, true);
    BitArray b2(5, true);
    EXPECT_TRUE(b1 == b2);
    b2.reset(2);
    EXPECT_FALSE(b1 == b2);
}

TEST(BitArrayTest, InequalityOperator) {
    BitArray b1(5, true);
    BitArray b2(5, true);
    EXPECT_FALSE(b1 != b2);
    b2.reset(2);
    EXPECT_TRUE(b1 != b2);
}

TEST(BitArrayTest, BitwiseAndOperator) {
    BitArray b1(5, true);
    BitArray b2(5, false);
    BitArray b3 = b1 & b2;
    EXPECT_EQ(b3.count(), 0);
}

TEST(BitArrayTest, BitwiseOrOperator) {
    BitArray b1(5, true);
    BitArray b2(5, false);
    BitArray b3 = b1 | b2;
    EXPECT_EQ(b3.count(), 5);
}

TEST(BitArrayTest, BitwiseXorOperator) {
    BitArray b1(5, true);
    BitArray b2(5, true);
    BitArray b3 = b1 ^ b2;
    EXPECT_EQ(b3.count(), 0);
}
